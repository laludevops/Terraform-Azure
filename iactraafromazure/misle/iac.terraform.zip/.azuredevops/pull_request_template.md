Thank you for your contribution to the Merlion Terraform repo. 

Before submitting this PR, please make sure:

- [ ] Your code builds clean without any errors or warnings
- [ ] You already perform terraform validate
- [ ] You already perform terraform init without error
- [ ] You already perform terraform plan without error