1. Get the follwoing inputs
    1. Resource type
    2. Prj code
    3. environment
    4. zone
    5. tier
    6. custom name
    8.  

2. thinsg to d0
    Clean the unwanted characters -- use the filetered module
    Throw error when the no of characters for each resouce is greater than the az limits
    


## Input
1. Map of object pof {}

2. Returns a map(object{
    
})