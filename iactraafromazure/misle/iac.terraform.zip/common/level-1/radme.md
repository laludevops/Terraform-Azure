# Landing zone level 1 for Common Subscription (DevOps and Managment)
## Components installed
1. Stroage Account for Network watcher flow logs
2. Log Analytics workspace
3. key vault
4. Devops Spoke 
   1. TMT subnet
   2. App Subnet
   3. SB subnet
   4. App AKS subnet
