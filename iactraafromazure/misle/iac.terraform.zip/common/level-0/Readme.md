# Landing zone Level 0 for Common Subscription (Devops & management spokes)

## Things created in the level

1. Log Analytics Workspace
2. Azure Key Vault
3. Storage Account : </br>
   a. Network Watcher </br>