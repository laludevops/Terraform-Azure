## TODOS
1. find the metric and logs for all the resources
2


## Confirm with client
1. law sol name  nam conv not working
2. naming conve for diagnostic settings -- > diagnsg (diag<res>)